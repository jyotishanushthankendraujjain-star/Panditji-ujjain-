
export type Language = 'hi' | 'en';
export type RashifalPeriod = 'daily' | 'weekly' | 'monthly' | 'yearly';

export interface ServiceItem {
  id: string;
  title: {
    hi: string;
    en: string;
  };
  description?: {
    hi: string;
    en: string;
  };
  icon?: string;
}

export interface ServiceCategory {
  id: string;
  name: {
    hi: string;
    en: string;
  };
  items: ServiceItem[];
}

export interface PredictionSet {
  daily: { hi: string; en: string };
  weekly: { hi: string; en: string };
  monthly: { hi: string; en: string };
  yearly: { hi: string; en: string };
}

export interface RashiData {
  id: string;
  name: {
    hi: string;
    en: string;
  };
  sanskritName: string;
  symbol: React.ReactNode;
  predictions: PredictionSet;
}

export interface Product {
  id: string;
  name: {
    hi: string;
    en: string;
  };
  price: number;
  image: string;
}
