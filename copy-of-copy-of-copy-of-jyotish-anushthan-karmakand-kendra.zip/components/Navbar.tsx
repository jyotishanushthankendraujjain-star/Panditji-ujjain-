
import React from 'react';
import { Language } from '../types';

interface NavbarProps {
  language: Language;
  onLanguageToggle: () => void;
  onMenuToggle: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ language, onLanguageToggle, onMenuToggle }) => {
  return (
    <header className="fixed top-0 right-0 left-0 md:left-72 bg-white/80 backdrop-blur-md z-30 border-b border-[#D4AF37]/10 px-6 py-4 flex items-center justify-between">
      <button 
        onClick={onMenuToggle}
        className="md:hidden p-2 text-[#7B1E1E]"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
        </svg>
      </button>

      <div className="hidden md:block">
        <span className="text-sm font-medium text-[#7B1E1E]/60 italic font-playfair">
          जय श्री महाकाल - Jai Shree Mahakal
        </span>
      </div>

      <div className="flex items-center space-x-6">
        <button 
          onClick={onLanguageToggle}
          className="flex items-center space-x-2 px-3 py-1.5 rounded-full border border-[#D4AF37]/30 hover:border-[#D4AF37] transition-colors"
        >
          <span className={`text-xs font-bold ${language === 'hi' ? 'text-[#D4AF37]' : 'text-gray-400'}`}>HI</span>
          <div className="w-px h-3 bg-gray-200" />
          <span className={`text-xs font-bold ${language === 'en' ? 'text-[#D4AF37]' : 'text-gray-400'}`}>EN</span>
        </button>
        
        <button className="gold-gradient text-white px-5 py-2 rounded-full text-xs font-bold shadow-md hover:scale-105 transition-transform">
          {language === 'hi' ? 'परामर्श लें' : 'Consult Now'}
        </button>
      </div>
    </header>
  );
};

export default Navbar;
