
import React from 'react';
import { Language } from '../types';
import { PANCHANG_DATA } from '../constants';

const PanchangWidget: React.FC<{ language: Language }> = ({ language }) => {
  const date = new Date().toLocaleDateString(language === 'hi' ? 'hi-IN' : 'en-US', { 
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' 
  });

  return (
    <div className="bg-white rounded-[2rem] p-8 shadow-xl border border-[#D4AF37]/20 relative overflow-hidden group hover:shadow-[#D4AF37]/10 transition-all">
      <div className="absolute top-0 right-0 bg-[#D4AF37] text-white text-[10px] font-bold px-4 py-1 rounded-bl-xl uppercase tracking-widest">
        {language === 'hi' ? 'आज का पंचांग' : 'Today\'s Panchang'}
      </div>
      
      <div className="flex items-center space-x-4 mb-6">
        <div className="text-4xl">📅</div>
        <div>
           <p className="text-xs text-gray-400 font-bold uppercase tracking-wider">
             {language === 'hi' ? 'उज्जैन, भारत' : 'Ujjain, India'}
           </p>
           <h3 className="text-lg font-devanagari font-bold text-[#7B1E1E]">{date}</h3>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 text-sm">
        <div className="bg-[#FFF8E7] p-3 rounded-xl border border-[#D4AF37]/10">
           <span className="block text-[10px] text-[#D4AF37] font-bold uppercase">Tithi</span>
           <span className="font-devanagari font-bold text-[#7B1E1E]">
             {language === 'hi' ? PANCHANG_DATA.tithi.hi : PANCHANG_DATA.tithi.en}
           </span>
        </div>
        <div className="bg-[#FFF8E7] p-3 rounded-xl border border-[#D4AF37]/10">
           <span className="block text-[10px] text-[#D4AF37] font-bold uppercase">Nakshatra</span>
           <span className="font-devanagari font-bold text-[#7B1E1E]">
             {language === 'hi' ? PANCHANG_DATA.nakshatra.hi : PANCHANG_DATA.nakshatra.en}
           </span>
        </div>
        <div className="bg-[#FFF8E7] p-3 rounded-xl border border-[#D4AF37]/10">
           <span className="block text-[10px] text-[#D4AF37] font-bold uppercase">Yog</span>
           <span className="font-devanagari font-bold text-[#7B1E1E]">
             {language === 'hi' ? PANCHANG_DATA.yog.hi : PANCHANG_DATA.yog.en}
           </span>
        </div>
        <div className="bg-[#7B1E1E]/5 p-3 rounded-xl border border-[#7B1E1E]/10">
           <span className="block text-[10px] text-[#7B1E1E] font-bold uppercase">Rahu Kaal</span>
           <span className="font-bold text-[#7B1E1E]">{PANCHANG_DATA.rahukaal}</span>
        </div>
      </div>
    </div>
  );
};

export default PanchangWidget;
