
import React, { useState } from 'react';
import { Language } from '../types';
import { BHAKTI_SAGAR_DATA, DIVINE_ICONS } from '../constants';

type BhaktiCategory = 'aarti' | 'mantra' | 'chalisa' | 'shlok' | 'strotam';

const BhaktiSagarPage: React.FC<{ language: Language }> = ({ language }) => {
  const [activeTab, setActiveTab] = useState<BhaktiCategory>('aarti');
  const [selectedItem, setSelectedItem] = useState<any>(null);

  const tabs: { id: BhaktiCategory; hi: string; en: string; icon: string }[] = [
    { id: 'aarti', hi: 'आरती', en: 'Aarti', icon: '🪔' },
    { id: 'mantra', hi: 'मंत्र', en: 'Mantra', icon: '📿' },
    { id: 'chalisa', hi: 'चालीसा', en: 'Chalisa', icon: '📖' },
    { id: 'shlok', hi: 'श्लोक', en: 'Shlok', icon: '📜' },
    { id: 'strotam', hi: 'स्तोत्रम्', en: 'Stotram', icon: '🔱' },
  ];

  // Fixed: Cast BHAKTI_SAGAR_DATA[activeTab] to any[] to resolve TypeScript type inference issues 
  // when using reduce on an array that could be never[] or have slightly different element types.
  const currentData = (BHAKTI_SAGAR_DATA as any)[activeTab] as any[];

  // Group current data by deity
  const groupedData = currentData.reduce((acc: Record<string, any[]>, item: any) => {
    const deityKey = language === 'hi' ? item.deity.hi : item.deity.en;
    if (!acc[deityKey]) acc[deityKey] = [];
    acc[deityKey].push(item);
    return acc;
  }, {} as Record<string, any[]>);

  const deityHeaders = Object.keys(groupedData);

  return (
    <div className={`pb-24 pt-32 px-6 md:px-12 min-h-screen transition-all duration-1000 ${selectedItem ? 'bg-black' : 'bg-white'}`}>
      <div className="max-w-7xl mx-auto">
        {!selectedItem && (
          <div className="animate-fade-in">
            <div className="text-center mb-16">
              <span className="text-[#D4AF37] font-bold text-sm tracking-[0.4em] uppercase opacity-70">The Celestial Treasury</span>
              <h1 className="text-5xl md:text-8xl font-devanagari font-bold text-[#7B1E1E] mt-4 mb-6 shlok-mask leading-tight">
                {language === 'hi' ? 'भक्ति सागर' : 'Bhakti Sagar'}
              </h1>
              <div className="flex items-center justify-center space-x-6 opacity-40">
                <div className="h-[1px] w-20 bg-gradient-to-r from-transparent to-[#D4AF37]"></div>
                <DIVINE_ICONS.Om className="w-10 h-10 text-[#D4AF37] animate-flicker" />
                <div className="h-[1px] w-20 bg-gradient-to-l from-transparent to-[#D4AF37]"></div>
              </div>
            </div>

            {/* Tab Selection */}
            <div className="flex flex-wrap justify-center gap-5 mb-24">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`
                    px-10 py-5 rounded-full font-bold transition-all duration-500 flex items-center space-x-4 border-2
                    ${activeTab === tab.id 
                      ? 'gold-gradient text-white border-transparent shadow-[0_10px_40px_rgba(212,175,55,0.4)] scale-110' 
                      : 'bg-white text-[#7B1E1E]/60 border-[#D4AF37]/20 hover:border-[#D4AF37] hover:bg-[#FFF8E7]'}
                  `}
                >
                  <span className="text-2xl">{tab.icon}</span>
                  <span className={`tracking-wider ${language === 'hi' ? 'font-devanagari text-xl' : 'text-sm'}`}>
                    {language === 'hi' ? tab.hi : tab.en}
                  </span>
                </button>
              ))}
            </div>

            <div className="space-y-24">
              {deityHeaders.map((deity) => (
                <div key={deity} className="relative">
                  <div className="flex items-center mb-10 border-b-2 border-[#D4AF37]/10 pb-6 sticky top-[100px] bg-white/90 backdrop-blur-xl z-20">
                    <div className="w-16 h-16 bg-[#FFF8E7] rounded-[1.5rem] flex items-center justify-center mr-6 text-3xl shadow-inner border border-[#D4AF37]/20 animate-float">
                      ✨
                    </div>
                    <h2 className="text-3xl md:text-5xl font-devanagari font-bold text-[#7B1E1E] tracking-tight">
                      {deity}
                    </h2>
                    <div className="ml-auto opacity-20 hidden md:block">
                       <DIVINE_ICONS.Lotus className="w-12 h-12 text-[#D4AF37]" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {groupedData[deity].map((item: any, idx: number) => (
                      <div 
                        key={idx}
                        onClick={() => setSelectedItem(item)}
                        className="bg-white p-10 rounded-[3rem] divine-shadow border border-[#D4AF37]/10 hover:border-[#D4AF37] transition-all duration-700 cursor-pointer group relative overflow-hidden flex flex-col justify-between"
                      >
                        {item.image && (
                          <div className="absolute inset-0 opacity-0 group-hover:opacity-[0.08] transition-opacity duration-1000">
                             <img src={item.image} alt="" className="w-full h-full object-cover grayscale" />
                          </div>
                        )}
                        <div className="relative z-10">
                          <span className="text-[10px] font-black text-[#D4AF37] uppercase tracking-[0.4em] mb-4 block opacity-60">Eternal Verse</span>
                          <h3 className="text-2xl md:text-3xl font-devanagari font-bold text-[#7B1E1E] group-hover:text-[#D4AF37] transition-colors duration-500 leading-tight">
                            {language === 'hi' ? item.title.hi : item.title.en}
                          </h3>
                        </div>
                        <div className="flex items-center justify-between pt-10 border-t border-[#D4AF37]/5 relative z-10">
                          <div className="flex -space-x-2">
                             {[...Array(3)].map((_, i) => <div key={i} className="w-2 h-2 rounded-full bg-[#D4AF37]/20"></div>)}
                          </div>
                          <button className="text-[#D4AF37] font-black text-sm flex items-center group-hover:translate-x-3 transition-all duration-500 uppercase tracking-widest">
                             {language === 'hi' ? 'दर्शन करें' : 'View Divine'} →
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Detailed Immersive View */}
        {selectedItem && (
          <div className="fixed inset-0 z-[100] flex flex-col bg-black text-white animate-fade-in overflow-y-auto overflow-x-hidden">
             {/* Background Deity Image with Cinematic Fog */}
             <div className="fixed inset-0 pointer-events-none select-none">
                <img 
                  src={selectedItem.image || 'https://images.unsplash.com/photo-1635345155465-98317789319e?q=80&w=1200'} 
                  alt="" 
                  className="w-full h-full object-cover opacity-20 filter blur-[2px] scale-110" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent"></div>
                <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black"></div>
             </div>

             <div className="relative z-10 w-full max-w-5xl mx-auto px-6 py-20 min-h-screen flex flex-col">
                <button 
                  onClick={() => setSelectedItem(null)}
                  className="fixed top-12 left-12 bg-white/10 backdrop-blur-xl border border-white/20 p-5 rounded-full text-white hover:bg-white hover:text-black transition-all duration-500 hover:scale-110"
                >
                  <span className="text-2xl">←</span>
                </button>

                <div className="text-center mb-16 mt-10 md:mt-20">
                   <div className="inline-block px-6 py-2 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#D4AF37] text-xs font-black tracking-[0.5em] uppercase mb-8 animate-float">
                     {language === 'hi' ? selectedItem.deity.hi : selectedItem.deity.en}
                   </div>
                   <h2 className="text-5xl md:text-8xl font-devanagari font-bold mb-10 text-white drop-shadow-[0_0_20px_rgba(212,175,55,0.4)]">
                     {language === 'hi' ? selectedItem.title.hi : selectedItem.title.en}
                   </h2>
                   <div className="flex items-center justify-center space-x-6">
                      <div className="h-px w-24 bg-gradient-to-r from-transparent to-[#D4AF37]"></div>
                      <DIVINE_ICONS.Trishul className="w-8 h-8 text-[#D4AF37] animate-flicker" />
                      <div className="h-px w-24 bg-gradient-to-l from-transparent to-[#D4AF37]"></div>
                   </div>
                </div>

                <div className="flex-1 flex flex-col items-center justify-center">
                   <div className="w-full bg-white/[0.03] backdrop-blur-3xl rounded-[4rem] p-10 md:p-24 border border-white/10 shadow-[0_0_100px_rgba(0,0,0,0.5)] relative">
                      <div className="absolute top-10 left-10 opacity-[0.05] pointer-events-none">
                         <DIVINE_ICONS.Om className="w-40 h-40 text-white" />
                      </div>
                      <pre className="whitespace-pre-wrap font-devanagari text-2xl md:text-5xl text-white/90 leading-[1.8] italic font-medium tracking-wide text-center">
                        {language === 'hi' ? selectedItem.content.hi : selectedItem.content.en}
                      </pre>
                      <div className="absolute bottom-10 right-10 opacity-[0.05] pointer-events-none">
                         <DIVINE_ICONS.Trishul className="w-40 h-40 text-white rotate-180" />
                      </div>
                   </div>
                </div>

                <div className="mt-20 text-center pb-20">
                   <p className="text-[#D4AF37] font-black text-2xl tracking-[0.3em] uppercase opacity-70">
                     || {language === 'hi' ? 'इति शुभम' : 'Divine Completion'} ||
                   </p>
                   <div className="mt-12 flex justify-center space-x-12 opacity-30">
                      <DIVINE_ICONS.Damru className="w-14 h-14 text-white" />
                      <DIVINE_ICONS.Lotus className="w-14 h-14 text-white" />
                   </div>
                </div>
             </div>
          </div>
        )}

        <div className="mt-40 text-center pb-20">
           <div className="w-48 h-1 gold-gradient mx-auto mb-16 opacity-30 rounded-full"></div>
           <p className="text-3xl md:text-5xl font-devanagari font-bold italic shlok-mask leading-relaxed max-w-5xl mx-auto drop-shadow-sm">
             “नमो नमस्तेऽस्तु सहस्रकृत्वः पुनश्च भूयोऽपि नमो नमस्ते।”
           </p>
           <p className="text-lg text-gray-400 mt-8 font-playfair italic tracking-[0.2em] uppercase">
             {language === 'hi' 
               ? '- कोटि-कोटि नमन -' 
               : '- Eternal Salutations -'}
           </p>
        </div>
      </div>
    </div>
  );
};

export default BhaktiSagarPage;
