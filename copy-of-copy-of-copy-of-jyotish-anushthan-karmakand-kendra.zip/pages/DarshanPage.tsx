import React from 'react';
import { Language } from '../types';
import { DARSHAN_DATA, DIVINE_ICONS } from '../constants';

const DarshanPage: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="pt-32 pb-24 px-6 md:px-12 bg-white min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <span className="text-[#D4AF37] font-bold text-xs tracking-[0.4em] uppercase font-devanagari">पवित्र यात्रा</span>
          <h1 className="text-4xl md:text-7xl font-devanagari font-bold text-[#7B1E1E] mt-4 mb-6 shlok-mask">
            {language === 'hi' ? 'उज्जैन दर्शन' : 'Ujjain Darshan'}
          </h1>
          <div className="flex items-center justify-center space-x-4 opacity-30">
            <div className="h-px w-16 bg-[#7B1E1E]"></div>
            <DIVINE_ICONS.Trishul className="w-8 h-8 text-[#D4AF37]" />
            <div className="h-px w-16 bg-[#7B1E1E]"></div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {DARSHAN_DATA.map((site) => (
            <div key={site.id} className="group relative h-[500px] md:h-[600px] rounded-[2.5rem] overflow-hidden shadow-2xl transition-all duration-700 hover:shadow-[#D4AF37]/20 border border-gray-100">
              <img src={site.image} alt={site.name.en} className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-[2000ms]" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent"></div>
              
              <div className="absolute inset-0 flex flex-col justify-end p-8 md:p-12 text-white">
                <span className="text-[10px] font-black tracking-[0.3em] uppercase text-[#D4AF37] mb-2 font-devanagari">अवन्तिका क्षेत्र</span>
                <h3 className="text-2xl md:text-4xl font-devanagari font-bold mb-4">
                  {language === 'hi' ? site.name.hi : site.name.en}
                </h3>
                <p className="text-sm md:text-lg font-devanagari italic leading-relaxed opacity-90 line-clamp-3 md:line-clamp-none">
                  {language === 'hi' ? site.desc.hi : site.desc.en}
                </p>
                <div className="mt-8 flex items-center space-x-4">
                  <button className="gold-gradient px-6 py-3 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg active:scale-95 transition-all">
                    {language === 'hi' ? 'दर्शन व्यवस्था' : 'Arrangements'}
                  </button>
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-xl animate-pulse">
                    🔱
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DarshanPage;