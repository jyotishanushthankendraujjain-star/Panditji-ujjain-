
import React from 'react';
import { Language } from '../types';
import { BLOG_DATA, DIVINE_ICONS } from '../constants';

const BlogPage: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="pt-32 pb-24 px-6 md:px-12 bg-[#FFF8E7]/30 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <span className="text-[#D4AF37] font-bold text-xs tracking-[0.4em] uppercase font-devanagari">ज्ञान गंगा</span>
          <h1 className="text-4xl md:text-7xl font-devanagari font-bold text-[#7B1E1E] mt-4 mb-6 shlok-mask">
            {language === 'hi' ? 'वैदिक ज्ञान एवं परंपरा' : 'Vedic Wisdom & Traditions'}
          </h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {BLOG_DATA.map((post) => (
            <div key={post.id} className="bg-white rounded-[3.5rem] overflow-hidden shadow-2xl group cursor-pointer hover:shadow-[#D4AF37]/10 transition-all">
              <div className="h-80 overflow-hidden relative">
                <img src={post.image} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" />
                <div className="absolute bottom-6 left-6 bg-[#7B1E1E] text-white px-4 py-1.5 rounded-full text-xs font-bold">{post.date}</div>
              </div>
              <div className="p-12">
                <h3 className="text-2xl md:text-3xl font-devanagari font-bold text-[#7B1E1E] mb-6 leading-tight group-hover:text-[#D4AF37] transition-colors">
                  {language === 'hi' ? post.title.hi : post.title.en}
                </h3>
                <p className="text-gray-500 font-devanagari mb-8 line-clamp-3">
                  {language === 'hi' 
                    ? 'उज्जैन की पावन नगरी और महाकाल की दिव्यता से जुड़े शास्त्रों के अनमोल रहस्यों को विस्तार से जानें।' 
                    : 'Explore the priceless secrets of scriptures associated with the holy city of Ujjain and Mahakal\'s divinity.'}
                </p>
                <button className="text-[#D4AF37] font-black text-xs uppercase tracking-[0.3em] flex items-center group-hover:translate-x-2 transition-transform">
                  Read More <span className="ml-3">→</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BlogPage;
