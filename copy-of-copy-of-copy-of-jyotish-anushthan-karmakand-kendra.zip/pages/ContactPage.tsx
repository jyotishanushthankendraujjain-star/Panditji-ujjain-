import React from 'react';
import { Language } from '../types';
import { DIVINE_ICONS } from '../constants';

const ContactPage: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="pt-32 pb-24 px-6 md:px-12 bg-[#FFF8E7]/30 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 animate-reveal">
          <span className="text-[#D4AF37] font-bold text-xs tracking-[0.4em] uppercase font-devanagari">सम्पर्क करें</span>
          <h1 className="text-4xl md:text-7xl font-devanagari font-bold text-[#7B1E1E] mt-4 mb-6 shlok-mask">
            {language === 'hi' ? 'हमसे जुड़ें' : 'Connect With Us'}
          </h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div className="bg-white p-12 md:p-16 rounded-[4rem] shadow-2xl border border-gray-100">
            <h3 className="text-3xl font-devanagari font-bold text-[#7B1E1E] mb-10">सम्पर्क सूत्र</h3>
            <div className="space-y-10">
              <div className="flex items-start">
                <div className="w-14 h-14 bg-[#FFF1B8] rounded-2xl flex items-center justify-center text-2xl mr-6">📍</div>
                <div>
                  <h4 className="font-bold text-[#7B1E1E] text-xl mb-1">{language === 'hi' ? 'पता' : 'Address'}</h4>
                  <p className="text-gray-600 font-devanagari italic">रामघाट मार्ग, उज्जैन, मध्य प्रदेश - 456001</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-14 h-14 bg-[#FFF1B8] rounded-2xl flex items-center justify-center text-2xl mr-6">📞</div>
                <div>
                  <h4 className="font-bold text-[#7B1E1E] text-xl mb-1">{language === 'hi' ? 'फ़ोन' : 'Phone'}</h4>
                  <p className="text-gray-600 font-bold">+91 98765 43210</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-14 h-14 bg-[#FFF1B8] rounded-2xl flex items-center justify-center text-2xl mr-6">✉️</div>
                <div>
                  <h4 className="font-bold text-[#7B1E1E] text-xl mb-1">{language === 'hi' ? 'ईमेल' : 'Email'}</h4>
                  <p className="text-gray-600 font-bold">om@ujjainpanditji.com</p>
                </div>
              </div>
            </div>
            <div className="mt-16 p-8 bg-[#7B1E1E] rounded-[2.5rem] text-white flex items-center">
               <DIVINE_ICONS.Om className="w-10 h-10 text-[#D4AF37] mr-6 animate-flicker" />
               <p className="font-devanagari font-bold text-lg">“शुभं करोति कल्याणं आरोग्यं धनसम्पदा”</p>
            </div>
          </div>

          <form className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <input type="text" placeholder={language === 'hi' ? 'पूरा नाम' : 'Full Name'} className="w-full px-8 py-5 rounded-full border-2 border-gray-100 focus:border-[#D4AF37] focus:ring-0 font-devanagari outline-none" />
              <input type="tel" placeholder={language === 'hi' ? 'मोबाइल नंबर' : 'Mobile Number'} className="w-full px-8 py-5 rounded-full border-2 border-gray-100 focus:border-[#D4AF37] focus:ring-0 font-devanagari outline-none" />
            </div>
            <select className="w-full px-8 py-5 rounded-full border-2 border-gray-100 focus:border-[#D4AF37] focus:ring-0 font-devanagari outline-none">
              <option>{language === 'hi' ? 'सेवा चुनें' : 'Select Service'}</option>
              <option>Jyotish</option>
              <option>Anushthan</option>
              <option>Karmakand</option>
            </select>
            <textarea placeholder={language === 'hi' ? 'आपका संदेश' : 'Your Message'} className="w-full h-48 px-8 py-6 rounded-[2.5rem] border-2 border-gray-100 focus:border-[#D4AF37] focus:ring-0 font-devanagari outline-none"></textarea>
            <button type="submit" className="gold-gradient text-white px-12 py-5 rounded-full font-black text-xl shadow-2xl hover:scale-105 transition-all w-full md:w-auto">
              {language === 'hi' ? 'सन्देश भेजें' : 'Send Message'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;