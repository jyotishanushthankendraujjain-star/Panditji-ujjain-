
import React, { useState, useEffect } from 'react';
import { Language, RashifalPeriod } from '../types';
import { RASHIFAL_DATA, COLORS, DIVINE_ICONS } from '../constants';

const RashifalPage: React.FC<{ language: Language }> = ({ language }) => {
  const [selectedRashi, setSelectedRashi] = useState<string>('aries');
  const [period, setPeriod] = useState<RashifalPeriod>('daily');
  const [currentDate, setCurrentDate] = useState<string>('');

  useEffect(() => {
    const options: Intl.DateTimeFormatOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const dateStr = new Date().toLocaleDateString(language === 'hi' ? 'hi-IN' : 'en-US', options);
    setCurrentDate(dateStr);
  }, [language]);

  const activeRashi = RASHIFAL_DATA.find(r => r.id === selectedRashi) || RASHIFAL_DATA[0];

  const periods: { id: RashifalPeriod; hi: string; en: string }[] = [
    { id: 'daily', hi: 'दैनिक', en: 'Daily' },
    { id: 'weekly', hi: 'साप्ताहिक', en: 'Weekly' },
    { id: 'monthly', hi: 'मासिक', en: 'Monthly' },
    { id: 'yearly', hi: 'वार्षिक', en: 'Yearly' }
  ];

  return (
    <div className="pt-32 pb-24 px-6 md:px-12 bg-white relative overflow-hidden">
      {/* Background Sacred Decorations */}
      <div className="absolute top-40 right-[-100px] opacity-[0.03] rotate-45 select-none pointer-events-none">
        <DIVINE_ICONS.Om className="w-[600px] h-[600px] text-[#7B1E1E]" />
      </div>

      <div className="max-w-7xl mx-auto">
        {/* Header Section */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 text-[#D4AF37] mb-4">
            <span className="animate-flicker">✨</span>
            <span className="text-sm font-bold tracking-[0.3em] uppercase">{language === 'hi' ? 'ग्रह नक्षत्र गणना' : 'Planetary Calculations'}</span>
            <span className="animate-flicker">✨</span>
          </div>
          <h1 className="text-4xl md:text-7xl font-devanagari font-bold text-[#7B1E1E] mb-6 shlok-mask">
            {language === 'hi' ? 'राशिफल २०२४-२५' : 'Rashifal 2024-25'}
          </h1>
          <p className="text-gray-500 font-medium font-devanagari text-lg flex items-center justify-center">
            <span className="mr-3">📅</span>
            {currentDate}
          </p>
        </div>

        {/* Period Selector Tabs */}
        <div className="flex justify-center mb-12">
          <div className="bg-[#FFF8E7] p-1.5 rounded-full border border-[#D4AF37]/20 flex space-x-2 shadow-inner">
            {periods.map((p) => (
              <button
                key={p.id}
                onClick={() => setPeriod(p.id)}
                className={`
                  px-6 md:px-10 py-2.5 rounded-full text-sm font-bold transition-all duration-300
                  ${period === p.id 
                    ? 'gold-gradient text-white shadow-lg' 
                    : 'text-[#7B1E1E]/60 hover:text-[#7B1E1E] hover:bg-white/50'}
                `}
              >
                {language === 'hi' ? p.hi : p.en}
              </button>
            ))}
          </div>
        </div>

        {/* Rashi Selection Grid */}
        <div className="grid grid-cols-4 md:grid-cols-6 lg:grid-cols-12 gap-3 mb-16">
          {RASHIFAL_DATA.map((rashi) => (
            <button
              key={rashi.id}
              onClick={() => setSelectedRashi(rashi.id)}
              className={`
                group relative aspect-square rounded-2xl border transition-all duration-500 flex flex-col items-center justify-center
                ${selectedRashi === rashi.id 
                  ? 'border-[#D4AF37] bg-[#FFF1B8]/30 shadow-[0_0_20px_rgba(212,175,55,0.3)] scale-110 z-10' 
                  : 'border-[#D4AF37]/10 bg-white hover:border-[#D4AF37]/40 hover:bg-[#FFF8E7]/40'}
              `}
            >
              <span className={`text-3xl md:text-4xl mb-1 group-hover:scale-125 transition-transform ${selectedRashi === rashi.id ? 'animate-flicker' : ''}`}>
                {rashi.symbol}
              </span>
              <span className={`text-[10px] md:text-xs font-bold font-devanagari tracking-tighter ${selectedRashi === rashi.id ? 'text-[#D4AF37]' : 'text-[#7B1E1E]/40'}`}>
                {language === 'hi' ? rashi.name.hi : rashi.name.en}
              </span>
              {selectedRashi === rashi.id && (
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-[#D4AF37] blur-sm animate-pulse opacity-50" />
              )}
            </button>
          ))}
        </div>

        {/* Prediction Display Card */}
        <div className="relative group">
          {/* Decorative Corner Icons */}
          <div className="absolute top-[-20px] left-[-20px] z-20 opacity-40">
             <DIVINE_ICONS.Trishul className="w-12 h-12 text-[#D4AF37]" />
          </div>
          <div className="absolute bottom-[-20px] right-[-20px] z-20 opacity-40">
             <DIVINE_ICONS.Damru className="w-12 h-12 text-[#D4AF37]" />
          </div>

          <div className="bg-white rounded-[3rem] p-8 md:p-16 divine-shadow border border-[#D4AF37]/20 relative overflow-hidden transition-all duration-500 hover:border-[#D4AF37]/50">
            {/* Watermark in Card */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-[0.03] pointer-events-none">
               <span className="text-[200px]">{activeRashi.symbol}</span>
            </div>

            <div className="flex flex-col md:flex-row items-center justify-between mb-12 border-b border-[#D4AF37]/10 pb-10">
              <div className="text-center md:text-left mb-8 md:mb-0">
                <span className="text-xs font-bold text-[#D4AF37] uppercase tracking-[0.4em] block mb-2">
                   {activeRashi.sanskritName} Rashi
                </span>
                <h2 className="text-4xl md:text-6xl font-devanagari font-bold text-[#7B1E1E] flex items-center">
                  {language === 'hi' ? activeRashi.name.hi : activeRashi.name.en}
                  <span className="ml-4 text-3xl opacity-50">{activeRashi.symbol}</span>
                </h2>
              </div>

              <div className="flex flex-col items-center md:items-end">
                <div className="flex space-x-1 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className="text-[#D4AF37] text-xl">✦</span>
                  ))}
                </div>
                <p className="text-sm font-bold text-[#D4AF37]/60 uppercase tracking-widest italic">
                  {language === 'hi' ? 'शुद्ध वैदिक फलादेश' : 'Pure Vedic Predictions'}
                </p>
              </div>
            </div>

            <div className="relative z-10">
              <div className="flex items-start mb-8">
                <div className="w-12 h-12 rounded-2xl bg-[#FFF8E7] flex items-center justify-center mr-6 text-2xl animate-pulse">✨</div>
                <div>
                  <h3 className="text-xl font-bold text-[#D4AF37] mb-4 uppercase tracking-wider">
                    {periods.find(p => p.id === period)?.[language]} {language === 'hi' ? 'फलादेश' : 'Prediction'}
                  </h3>
                  <p className="text-2xl md:text-3xl font-devanagari text-gray-700 leading-[1.6] italic font-medium">
                    “{activeRashi.predictions[period][language]}”
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 pt-10 border-t border-[#D4AF37]/5">
                 <div className="p-6 rounded-3xl bg-[#FFF8E7]/40 border border-[#D4AF37]/10 hover:bg-white transition-all">
                    <p className="text-xs font-bold text-[#D4AF37] uppercase tracking-widest mb-2">शुभ अंक (Lucky Number)</p>
                    <p className="text-2xl font-bold text-[#7B1E1E]">7, 9</p>
                 </div>
                 <div className="p-6 rounded-3xl bg-[#FFF8E7]/40 border border-[#D4AF37]/10 hover:bg-white transition-all">
                    <p className="text-xs font-bold text-[#D4AF37] uppercase tracking-widest mb-2">शुभ रंग (Lucky Color)</p>
                    <p className="text-2xl font-bold text-[#7B1E1E]">{language === 'hi' ? 'सुनहरा' : 'Golden'}</p>
                 </div>
                 <div className="p-6 rounded-3xl bg-[#FFF8E7]/40 border border-[#D4AF37]/10 hover:bg-white transition-all">
                    <p className="text-xs font-bold text-[#D4AF37] uppercase tracking-widest mb-2">शुभ रत्न (Gemstone)</p>
                    <p className="text-2xl font-bold text-[#7B1E1E]">{language === 'hi' ? 'पुखराज' : 'Yellow Sapphire'}</p>
                 </div>
              </div>

              <div className="mt-12 flex flex-col sm:flex-row justify-center gap-6">
                 <button className="gold-gradient text-white px-10 py-4 rounded-full font-bold shadow-xl hover:scale-105 transition-all">
                    {language === 'hi' ? 'विस्तृत ज्योतिष परामर्श' : 'Detailed Astrological Consultation'}
                 </button>
                 <button className="bg-white border-2 border-[#D4AF37] text-[#D4AF37] px-10 py-4 rounded-full font-bold hover:bg-[#FFF8E7] transition-all">
                    {language === 'hi' ? 'दोष निवारण उपाय' : 'Remedy for Dosha'}
                 </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Shlok for Rashifal */}
        <div className="mt-24 text-center">
           <p className="text-3xl font-devanagari font-bold italic shlok-mask leading-relaxed max-w-4xl mx-auto">
             “यथा शिखा मयूराणां, नागानां मणयो यथा।<br/>
             तद्वद् वेदांगशास्त्राणां, ज्योतिषं मूर्धनि स्थितम्॥”
           </p>
           <p className="text-sm text-gray-400 mt-4 italic">
             {language === 'hi' 
               ? '- ज्योतिष शास्त्र समस्त वेदांगों में शिरोमणि है।' 
               : '- Astrology is the crown jewel among all Vedic limbs.'}
           </p>
        </div>
      </div>
    </div>
  );
};

export default RashifalPage;
