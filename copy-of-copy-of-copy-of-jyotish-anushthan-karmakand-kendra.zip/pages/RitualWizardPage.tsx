
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Language } from '../types';
import { DIVINE_ICONS } from '../constants';

const RitualWizardPage: React.FC<{ language: Language }> = ({ language }) => {
  const [step, setStep] = useState(1);
  const [concern, setConcern] = useState('');
  const [recommendation, setRecommendation] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const getRecommendation = async () => {
    setIsLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
      const prompt = `Based on this concern: "${concern}", suggest the most appropriate Vedic Anushthan or Puja from Ujjain (e.g., Mahamrityunjaya, Kaal Sarp Dosh, Mangal Dosh, etc.). Explain WHY it is recommended and what the spiritual benefit is. Tone: Divine, scholarly, and supportive. Use ${language === 'hi' ? 'Hindi' : 'English'}.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: { systemInstruction: "You are Pandit ji from Ujjain, an expert in Karmakand and Jyotish." }
      });

      setRecommendation(response.text || '');
      setStep(3);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="pt-32 pb-24 px-6 md:px-12 bg-[#FFF8E7] min-h-screen flex items-center justify-center">
      <div className="max-w-4xl w-full bg-white rounded-[4rem] divine-shadow border border-[#D4AF37]/20 p-12 md:p-24 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 opacity-[0.05] p-10">
           <DIVINE_ICONS.Om className="w-40 h-40 text-[#7B1E1E]" />
        </div>

        {step === 1 && (
          <div className="text-center animate-fade-in">
            <span className="text-[#D4AF37] font-black text-xs tracking-[0.4em] uppercase mb-6 block">Divine Guidance</span>
            <h2 className="text-4xl md:text-6xl font-devanagari font-bold text-[#7B1E1E] mb-10 leading-tight">
              {language === 'hi' ? 'अपनी समस्या या मनोकामना साझा करें' : 'Share your concern or desire'}
            </h2>
            <p className="text-lg text-gray-500 italic mb-12">
              पंडित जी (AI) आपकी स्थिति के अनुसार सही अनुष्ठान का सुझाव देंगे।
            </p>
            <textarea 
              value={concern}
              onChange={(e) => setConcern(e.target.value)}
              className="w-full h-48 bg-[#FFF8E7]/50 rounded-[2rem] p-8 border-2 border-[#D4AF37]/10 focus:border-[#D4AF37] focus:ring-0 text-xl font-medium text-[#7B1E1E] mb-10 transition-all"
              placeholder={language === 'hi' ? 'उदाहरण: स्वास्थ्य समस्या, विवाह में विलम्ब, करियर में बाधा...' : 'e.g. Health issues, delay in marriage, career obstacles...'}
            />
            <button 
              onClick={() => concern.trim() && setStep(2)}
              disabled={!concern.trim()}
              className="gold-gradient text-white px-16 py-6 rounded-full text-xl font-black shadow-2xl hover:scale-105 transition-all disabled:opacity-50"
            >
              {language === 'hi' ? 'पंडित जी से पूछें' : 'Ask Pandit Ji'}
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="text-center py-20 animate-fade-in">
            <div className="w-24 h-24 bg-[#FFF1B8] rounded-full flex items-center justify-center mx-auto mb-10 border-2 border-[#D4AF37]/20 animate-flicker">
               <DIVINE_ICONS.Lotus className="w-12 h-12 text-[#D4AF37]" />
            </div>
            <h3 className="text-3xl font-devanagari font-bold text-[#7B1E1E] mb-6">
              {language === 'hi' ? 'पंडित जी ध्यान लगा रहे हैं...' : 'Pandit Ji is contemplating...'}
            </h3>
            <p className="text-gray-400 mb-12">ग्रहों की स्थिति और वैदिक शास्त्रों का विश्लेषण किया जा रहा है।</p>
            {!isLoading ? (
              <button 
                onClick={getRecommendation}
                className="gold-gradient text-white px-16 py-6 rounded-full text-xl font-black shadow-2xl"
              >
                {language === 'hi' ? 'उत्तर प्राप्त करें' : 'Get Recommendation'}
              </button>
            ) : (
              <div className="flex justify-center space-x-2">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="w-4 h-4 bg-[#D4AF37] rounded-full animate-bounce" style={{ animationDelay: `${i * 0.2}s` }} />
                ))}
              </div>
            )}
          </div>
        )}

        {step === 3 && (
          <div className="animate-fade-in">
            <div className="flex items-center space-x-6 mb-12 pb-8 border-b border-[#D4AF37]/10">
              <div className="w-16 h-16 bg-[#FFF1B8] rounded-2xl flex items-center justify-center text-3xl">📿</div>
              <h3 className="text-3xl font-devanagari font-bold text-[#7B1E1E]">पंडित जी का सुझाव (Divine Recommendation)</h3>
            </div>
            <div className="prose prose-xl text-[#7B1E1E] leading-relaxed italic mb-16 whitespace-pre-wrap">
              {recommendation}
            </div>
            <div className="flex flex-col sm:flex-row gap-6">
               <button className="gold-gradient text-white px-12 py-5 rounded-full font-black shadow-xl hover:scale-105 transition-all">
                  {language === 'hi' ? 'अभी बुकिंग करें' : 'Book Now'}
               </button>
               <button 
                  onClick={() => { setStep(1); setConcern(''); setRecommendation(''); }}
                  className="bg-white border-2 border-[#D4AF37] text-[#D4AF37] px-12 py-5 rounded-full font-black hover:bg-[#FFF8E7] transition-all"
               >
                  {language === 'hi' ? 'पुनः प्रयास करें' : 'Start Over'}
               </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RitualWizardPage;
